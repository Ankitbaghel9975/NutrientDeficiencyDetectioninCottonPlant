import React, { useRef, useState, useEffect } from "react";

const API_BASE_URL = "http://localhost:8000"; 

export default function CottonDiseaseFinder() {
  const fileInputRef = useRef(null);
  const [submitting, setSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const [form, setForm] = useState({
    name:  JSON.parse(localStorage.getItem("cotton_form_data"))?.name || "",
    email: JSON.parse(localStorage.getItem("cotton_form_data"))?.email || "",
    phone: JSON.parse(localStorage.getItem("cotton_form_data"))?.phone || "",
    village: JSON.parse(localStorage.getItem("cotton_form_data"))?.village || "",
    district: JSON.parse(localStorage.getItem("cotton_form_data"))?.district || "",
    state: JSON.parse(localStorage.getItem("cotton_form_data"))?.state || "",
    pincode: JSON.parse(localStorage.getItem("cotton_form_data"))?.pincode || "",
  });

  useEffect(() => {
  const saved = localStorage.getItem("cotton_form_data");
  if (saved) setForm(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("cotton_form_data", JSON.stringify(form));
  }, [form]);

  function updateField(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function onPickFileClick() {
    fileInputRef.current?.click();
  }

  function onFileSelected(f) {
    const file = f || fileInputRef.current?.files?.[0] || null;
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please upload a valid image file (JPEG/PNG).");
      return;
    }
    setImageFile(file);
    const url = URL.createObjectURL(file);
    setImagePreview(url);
  }

  function validate() {
    if (!form.name.trim()) return "Name is required";
    if (!form.state.trim()) return "State is required";
    if (!form.district.trim()) return "District is required";
    if (!imageFile) return "Please upload a cotton leaf image";
    return null;
  }

  async function handleSubmit(e) {
  e.preventDefault();
  setError(null);
  setResult(null);

  const err = validate();
  if (err) {
    setError(err);
    return;
  }

  try {
    setSubmitting(true);

    const fd = new FormData();
    // attach farmer details if you want them
    Object.entries(form).forEach(([k, v]) => fd.append(k, v));

    // IMPORTANT: backend expects "file", not "image"
    if (imageFile) fd.append("file", imageFile);

    const res = await fetch(`${API_BASE_URL}/predict/`, { // API call
      method: "POST",
      body: fd,
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(txt || `Request failed: ${res.status}`);
    }

    const data = await res.json();
    setResult(data);
  } catch (err) {
    setError(err?.message || "Something went wrong");
  } finally {
    setSubmitting(false);
  }
}


  function resetAll() {
    setForm({ name: "", email: "", phone: "", village: "", district: "", state: "", pincode: "" });
    setImageFile(null);
    setImagePreview(null);
    setResult(null);
    setError(null);
  }

  return (
    <div className="bg-light min-vh-100">
      {/* Title/Logo */}
      <header className="py-4 border-bottom bg-white">
        <div className="container d-flex align-items-center gap-3">
          <div
            aria-hidden="true"
            className="rounded-circle d-flex align-items-center justify-content-center"
            style={{ width: 44, height: 44, background: "#198754", color: "white", fontWeight: 700 }}
          >
            C
          </div>
          <div>
            <h1 className="h4 mb-0">Cotton Deficiency Finder</h1>
            <small className="text-muted">Upload leaf photo, fill details, get instant analysis</small>
          </div>
        </div>
      </header>

      <main className="container my-4">
        <form onSubmit={handleSubmit} className="row g-4">
          {/* Details */}
          <div className="col-12 col-lg-7">
            <div className="card shadow-sm">
              <div className="card-header bg-white"><strong>Farmer & Location</strong></div>
              <div className="card-body">
                <div className="row g-3">
                  <div className="col-12 col-md-6"><Input label="Name *" value={form.name} onChange={(v) => updateField("name", v)} /></div>
                  <div className="col-12 col-md-6"><Input label="Email" type="email" value={form.email} onChange={(v) => updateField("email", v)} /></div>
                  <div className="col-12 col-md-6"><Input label="Phone" value={form.phone} onChange={(v) => updateField("phone", v)} /></div>
                  <div className="col-12 col-md-6"><Input label="Village" value={form.village} onChange={(v) => updateField("village", v)} /></div>
                  <div className="col-12 col-md-6"><Input label="District *" value={form.district} onChange={(v) => updateField("district", v)} /></div>
                  <div className="col-12 col-md-6"><Input label="State *" value={form.state} onChange={(v) => updateField("state", v)} /></div>
                  <div className="col-12 col-md-6"><Input label="Pincode" value={form.pincode} onChange={(v) => updateField("pincode", v)} /></div>
                </div>
              </div>
            </div>
          </div>

          {/* Image upload */}
          <div className="col-12 col-lg-5">
            <div className="card shadow-sm">
              <div className="card-header bg-white"><strong>Upload Cotton Leaf Photo *</strong></div>
              <div className="card-body">
                <div className="text-center p-3 border border-2 border-secondary-subtle rounded" style={{ cursor: "pointer" }} onClick={onPickFileClick}>
                  {imagePreview ? (
                    <div>
                      <img src={imagePreview} alt="Preview" className="img-fluid rounded" style={{ maxHeight: 260, objectFit: "contain" }} />
                      <div className="form-text">Click to replace image</div>
                    </div>
                  ) : (
                    <>
                      <div className="display-6" aria-hidden="true">📷</div>
                      <p className="text-muted mb-0">Click to browse a clear leaf photo (JPEG/PNG)</p>
                    </>
                  )}
                  <input ref={fileInputRef} type="file" accept="image/*" className="d-none" onChange={() => onFileSelected()} />
                </div>

                <button type="submit" className="btn btn-success w-100 mt-3" disabled={submitting}>
                  {submitting ? "Analyzing..." : "Analyze Leaf"}
                </button>

                {error && <div className="alert alert-danger mt-3 mb-0" role="alert">{error}</div>}
              </div>
            </div>
          </div>
        </form>

        {/* Results */}
        <section className="mt-4">
          {submitting && (
            <div className="card shadow-sm"><div className="card-body">
              <div className="placeholder-glow">
                <span className="placeholder col-3"></span>
                <span className="placeholder col-6"></span>
                <span className="placeholder col-4"></span>
              </div>
            </div></div>
          )}

          {result && (
            <div className="row g-4">
              <div className="col-12 col-lg-8">
                <div className="card shadow-sm">
                  <div className="card-header bg-white"><strong>Diagnosis</strong></div>
                  <div className="card-body"><DiagnosisCard data={result} /></div>
                </div>
              </div>
              {/* <div className="col-12 col-lg-4">
                <div className="card shadow-sm">
                  <div className="card-header bg-white"><strong>Weather Snapshot</strong></div>
                  <div className="card-body"><WeatherCard data={result?.weather} /></div>
                </div>
              </div> */}
              <div className="col-12">
                <div className="d-flex gap-2">
                  <button className="btn btn-outline-secondary" onClick={() => window.print()}>Print / Save PDF</button>
                  <button className="btn btn-outline-secondary" onClick={resetAll}>New Analysis</button>
                </div>
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function Input({ label, value, onChange, type = "text" }) {
  const id = label.toLowerCase().replace(/\s+/g, "-");
  return (
    <div>
      <label htmlFor={id} className="form-label">{label}</label>
      <input id={id} type={type} value={value} onChange={(e) => onChange(e.target.value)} className="form-control" />
    </div>
  );
}

function DiagnosisCard({ data }) {
  const disease = data?.diagnosis?.disease || data?.prediction || "Unknown";
  const confidence = data?.diagnosis?.confidence ?? data?.confidence;
  const probability = typeof confidence === "number" ? `${(confidence * 100).toFixed(1)}%` : "-";
  const severity = data?.diagnosis?.severity || data?.severity || "Not available";
  const extra = data?.diagnosis?.extra || data?.extra || {};

  return (
    <div className="small">
      <KeyRow k="Disease" v={disease} />
      <KeyRow k="Confidence" v={probability} />
      <KeyRow k="Severity" v={severity} />
      {Object.keys(extra).length > 0 && (
        <div className="mt-3">
          <div className="fw-semibold mb-1">Details</div>
          <ul className="small mb-0">
            {Object.entries(extra).map(([k, v]) => (
              <li key={k}><span className="fw-semibold">{titleCase(k)}:</span> {String(v)}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function WeatherCard({ data }) {
  if (!data) return <p className="text-muted small mb-0">No weather data available.</p>;
  return (
    <div className="small">
      <KeyRow k="Temp" v={fmt(data.temp, "°C")} />
      <KeyRow k="Humidity" v={fmt(data.humidity, "%")} />
      <KeyRow k="Rain" v={fmt(data.rainfall_mm, " mm")} />
      <KeyRow k="Wind" v={fmt(data.wind_kph, " kph")} />
      {data.condition && <KeyRow k="Condition" v={data.condition} />}
      {data.station && <KeyRow k="Station" v={data.station} />}
    </div>
  );
}

function KeyRow({ k, v }) {
  return (
    <div className="d-flex justify-content-between border-bottom py-2">
      <span className="text-muted">{k}</span>
      <span className="fw-semibold">{String(v)}</span>
    </div>
  );
}

function fmt(v, suffix = "") {
  if (v === null || v === undefined || v === "") return "-";
  const n = Number(v);
  return isNaN(n) ? String(v) : `${n}${suffix}`;
}

function titleCase(s) {
  return s
    .replace(/[_-]/g, " ")
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}
